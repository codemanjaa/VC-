﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Calculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    int n1, n2;

    protected void numRetriever()
    {

        n1 = Convert.ToInt32(TextBox1.Text);
        n2 = Convert.ToInt32(TextBox2.Text);
        enablerbutton();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        numRetriever();
        String op = "+";
        localhost.CalculatorWebService ws = new localhost.CalculatorWebService();
        TextBox3.Text = ws.DoCalc(n1, n2, op).ToString();



    }

    protected void enablerbutton()
    {
        Button1.Enabled = true;
        Button2.Enabled = true;
        Button3.Enabled = true;
    }

    protected void disablerbutton()
    {
        Button1.Enabled = false;
        Button2.Enabled = false;
        Button3.Enabled = false;
    }




    protected void Button2_Click(object sender, EventArgs e)
    {


        numRetriever();
        String op = "-";
        localhost.CalculatorWebService ws = new localhost.CalculatorWebService();
        TextBox3.Text = ws.DoCalc(n1, n2, op).ToString();

    }

    protected void Button3_Click(object sender, EventArgs e)
    {

        numRetriever();
        String op = "*";
        localhost.CalculatorWebService ws = new localhost.CalculatorWebService();
        TextBox3.Text = ws.DoCalc(n1, n2, op).ToString();

    }



    protected void Button4_Click(object sender, EventArgs e)
    {

        numRetriever();
        String op = "/";
        localhost.CalculatorWebService ws = new localhost.CalculatorWebService();
        TextBox3.Text = ws.DoCalc(n1, n2, op).ToString();

    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        if (TextBox1.Text.Equals(""))
        {
            disablerbutton();
        }
        else
        {
            numRetriever();
            enablerbutton();
        }
    }
}