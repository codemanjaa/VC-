﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for CalculatorWebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class CalculatorWebService : System.Web.Services.WebService
{

    public CalculatorWebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }



    [WebMethod]
    public int DoCalc(int num1, int num2, String opr)
    {
        int n1 = num1;
        int n2 = num2;
        String op = opr;
        int ans = 0;
        if (op.Equals("+"))
        {
            ans = n1 + n2;

        }
        else if (op.Equals("-")){
            ans = n1 - n2;

        }
        else if (op.Equals("*"))
        {
            ans = n1 * n2;
        }
        else if (op.Equals("/"))
        {
            ans = n1 / n2;

        }


        return ans;
    }



    
}
