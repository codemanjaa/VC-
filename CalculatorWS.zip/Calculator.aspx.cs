﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Calculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    public void numConverter()
    {
        double n1 = Convert.ToDouble(TextBox1.Text);
        double n2 = Convert.ToDouble(TextBox4.Text);

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        numConverter();

    }

  
}