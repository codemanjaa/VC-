
WCFAjaxWebServiceExample

A simple example demonstrating the ease of use and Power of WCF AJAX Web Service

Link to accompaning Code Project Article: http://www.codeproject.com/Articles/887611/Simple-Demo-WCF-AJAX-Web-Service

I havent put up instructions here because the article above has brief steps on how to execute this project.

Have Fun!

